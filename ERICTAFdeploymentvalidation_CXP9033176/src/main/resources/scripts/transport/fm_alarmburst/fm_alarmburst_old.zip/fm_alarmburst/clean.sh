rm -rf *.txt
rm -rf *.resp
rm -rf *.sar
