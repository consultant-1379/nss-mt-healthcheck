#!/bin/bash


sleepTime=30
resultFile="result.csv"


# Storm
# Part 1 : Find max nodes that can send  1-N alarms/sec 
#TODO: Optimize time to find max nodes by binary search



echo "Storm Test" >> $resultFile

# 3 trails
for i in {1..2};do
	step=5
	frequency=0
	while [ true ];do
	nodes=10
	frequency=$((frequency + step))
	alarms=$((nodes*frequency))
	while [ true ];do
		sleep $sleepTime	
		sh alarmBurstExecutor_multiple.sh -n $nodes -a $alarms -f $frequency -o 1
		alarmsSent=$(cat $resultFile | tail -1 | cut -d"," -f 5)
		buffer=$(( alarms - 3 ))
		if [ $alarms -gt $alarmsSent ];then
			if [ $buffer -le $alarmsSent ]; then
				nodes=$((nodes+5))
                        	alarms=$((nodes*frequency))
			else
				break
			fi
		else
			
			nodes=$((nodes+5))
			alarms=$((nodes*frequency))
		fi
	done
	if [[ $nodes -eq 10 ]];then 
		break
	fi
	done
done


