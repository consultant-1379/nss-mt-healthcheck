~/inst/netsim_shell < ceaseFile.run
rm -rf ceaseFile.run
