
# Step 0 : get capability details

# Step 1 : check and run collector

# Step 2 : run trigger

# Step 3: generate prmn

# Step 4 : run analyzer

# Step 5 : secure results

# Step 6 : remove all intermediate file

# Step 7 : check if reached threshold point and goto Step 1 or Step 2 accordingly

